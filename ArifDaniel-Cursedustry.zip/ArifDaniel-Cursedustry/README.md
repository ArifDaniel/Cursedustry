# Cursedustry
Never gonna curse you up, Never gonna let you curse down

Version 0.01: cursed single unit: atrax
Version 0.1: cursed entire crawler tree
fixed "mod.json not found" error (changing hjson to json) and hopefully fixed js not working
Version 0.2: cursed dagger tree but not entirely and added bullets catergory
Version 0.25: cursed entire dagger tree and removed recoil from quasar's laser
fixed some bugs mistake and added new catergory "others"
added 'bundle' to dagger tree
removed non-released folders
unfixed bugs: many
