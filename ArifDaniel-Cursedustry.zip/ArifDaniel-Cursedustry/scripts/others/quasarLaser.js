Vars.enableConsole=true;

UnitTypes.quasar.weapons.each(w=>w.bullet.recoil=0);
