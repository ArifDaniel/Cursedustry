Vars.enableConsole=true;

Bullets.standardCopper.width=100;
Bullets.standardCopper.height=1000;
