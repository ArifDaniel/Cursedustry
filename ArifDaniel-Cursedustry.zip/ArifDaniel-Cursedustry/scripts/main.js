Vars.enableConsole = true;

//units

//crawler tree
require("units/crawler");
require("units/atrax");
require("units/spiroct");
require("units/arkyid");
require("units/toxopid");

//dagger tree
require("units/dagger");
require("units/mace");
require("units/fortress");
require("units/scepter");
require("units/reign");

//bullets

//standard copper
require("bullets/standardCopper");

//others
require("others/quasarLaser");
