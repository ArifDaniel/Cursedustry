Vars.enableConsole=true;

UnitTypes.arkyid.legCount=25;
UnitTypes.arkyid.legMoveSpace=0.5;
UnitTyupes.arkyid.legExtension=-150;

UnitTypes.arkyid.weapons.each(w=>w.bullet.length=100);
UnitTypes.arkyid.weapons.each(w=>w.bullet.speed=10);
UnitTypes.arkyid.weapons.each(w=>w.alternate=false);
UnitTypes.arkyid.range=100;
