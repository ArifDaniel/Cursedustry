Vars.enableConsole=true;

UnitTypes.dagger.weapons.each(w=>w.shootSound=(Blocks.duo.shootSound));
UnitTypes.dagger.weapons.each(w=>w.bullet=(Bullets.basicFlame));

UnitTypes.dagger.mechSideSway=10;
