Vars.enableConsole=true;

UnitTypes.reign.weapons.each(w=>w.shots=10);
UnitTypes.reign.weapons.each(w=>w.bullet.fragBullet=(UnitTypes.quad.weapons.get(0).bullet));
UnitTypes.reign.weapons.each(w=>w.bullet.fragBullets=1);

UnitTypes.reign.mechFrontSway=10;
UnitTypes.reign.mechSideSway=10;
