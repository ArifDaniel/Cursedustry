Vars.enableConsole=true;

UnitTypes.spiroct.legCount=10;
UnitTypes.spiroct.legLength=250;
UnitTypes.spiroct.legSpeed=2;
UnitTypes.spiroct.legMoveSpace=0.1;

UnitTypes.spiroct.weapons.each(w=>w.bullet.length=250);
UnitTypes.spiroct.range=250;
UnitTypes.spiroct.speed=1;
