Vars.enableConsole=true;

UnitTypes.fortress.weapons.each(w=>w.shootSound=(Blocks.fuse.shootSound));
UnitTypes.fortress.weapons.each(w=>w.bullet=(UnitTypes.sei.weapons.get(0)));
UnitTypes.fortress.weapons.each(w=>w.shots=2);

UnitTypes.fortress.mechFrontSway=10;
