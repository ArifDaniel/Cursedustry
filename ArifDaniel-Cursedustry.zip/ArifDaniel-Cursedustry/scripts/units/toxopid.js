Vars.enableConsole.true;

UnitTypes.toxopid.legCount=10;

UnitTypes.toxopid.weapons.each(w=>w.alternate=false);
UnitTypes.toxopid.weapons.each(w=>w.shots=1);
UnitTypes.toxopid.weapons.each(w=>w.reload=3);
UnitTypes.toxopid.weapons.each(w=>w.bullet.length=125);

UnitTypes.toxopid.weapons.get(2).bullet.weaveScale=5;
UnitTypes.toxopid.weapons.get(2).bullet.weaveMag=2;
UnitTypes.toxopid.weapons.get(2).shots=10;
UnitTypes.toxopid.weapons.get(2).bullet.homingPower=0.1;
UnitTypes.toxopid.weapons.get(2).bullet.homingRange=125;
UnitTypes.toxopid.weapons.get(2).reload=500;
UnitTypes.toxopid.weapons.get(2).fragBullets=10;
UnitTypes.toxopid.weapons.get(2).bullet.width=50;
UnitTypes.toxopid.weapons.get(2).bullet.height=50;
