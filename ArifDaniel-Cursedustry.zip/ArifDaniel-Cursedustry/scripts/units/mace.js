Vars.enableConsole=true;

UnitTypes.mace.weapons.each(w=>w.shootSound=(Blocks.arc.shootSound));
UnitTypes.mace.weapons.each(w=>w.bullet=(Bullets.standardCopper));

