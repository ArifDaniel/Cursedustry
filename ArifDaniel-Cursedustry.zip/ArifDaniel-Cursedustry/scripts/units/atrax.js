Vars.enableConsole = true;

UnitTypes.atrax.legCount=1;
UnitTypes.atrax.legLength=25;
UnitTypes.atrax.legExtension=100;

UnitTypes.atrax.weapons.each(w=>w.reload=8);
UnitTypes.atrax.weapons.each(w=>w.bullet.weaveScale=10);
UnitTypes.atrax.weapons.each(w=>w.bullet.weaveMag=2);
UnitTypes.atrax.weapons.each(w=>w.bullet.speed=5);
