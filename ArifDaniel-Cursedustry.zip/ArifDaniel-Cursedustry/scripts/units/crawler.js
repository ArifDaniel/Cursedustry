Vars.enableConsole=true;

UnitTypes.crawler.speed=5;
UnitTypes.crawler.mechFrontSway=25;
UnitTypes.crawler.mechSideSway=25;
UnitTypes.crawler.health=200;
