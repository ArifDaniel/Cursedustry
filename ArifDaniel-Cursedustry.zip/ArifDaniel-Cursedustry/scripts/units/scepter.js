Vars.enableConsole=true;

UnitTypes.scepter.weapons.get(0).bullet=(Blocks.lancer.shootType);
UnitTypes.scepter.weapons.get(1).bullet=(UnitTypes.quasar.weapons.get(0).bullet);
UnitTypes.scepter.weapons.get(2).bullet=(UnitTypes.pulsar.weapons.get(0).bullet);
UnitTypes.scepter.weapons.get(3).bullet=(UnitTypes.pulsar.weapons.get(0).bullet);
UnitTypes.scepter.weapons.get(4).bullet=(Blocks.arc.shootType);
UnitTypes.scepter.weapons.get(5).bullet=(Blocks.arc.shootType);

UnitTypes.scepter.weapons.get(0).shots=10;
UnitTypes.scepter.weapons.get(1).shots=10;
UnitTypes.scepter.weapons.get(2).shots=5;
UnitTypes.scepter.weapons.get(3).shots=5;
UnitTypes.scepter.weapons.get(4).shots=5;
UnitTypes.scepter.weapons.get(5).shots=5;
